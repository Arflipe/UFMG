#include "edge.hpp"

Edge::Edge(int adjacent, int flow){
	this->adjacent = adjacent;
	this->flow = flow;
}