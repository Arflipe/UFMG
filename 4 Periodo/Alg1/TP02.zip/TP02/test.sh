make clean
make

time ./tp02 < test_cases/inputs/test_case0.txt
time ./tp02 < test_cases/inputs/test_case1.txt
time ./tp02 < test_cases/inputs/test_case2.txt
time ./tp02 < test_cases/inputs/test_case3.txt
time ./tp02 < test_cases/inputs/test_case4.txt
time ./tp02 < test_cases/inputs/test_case5.txt
time ./tp02 < test_cases/inputs/test_case6.txt
time ./tp02 < test_cases/inputs/test_case7.txt
time ./tp02 < test_cases/inputs/test_case8.txt
time ./tp02 < test_cases/inputs/test_case9.txt
time ./tp02 < test_cases/inputs/test_case10.txt
time ./tp02 < test_cases/inputs/test_case11.txt
time ./tp02 < test_cases/inputs/test_case12.txt
time ./tp02 < test_cases/inputs/test_case13.txt
time ./tp02 < test_cases/inputs/test_case14.txt